$(function () {
  $('.select2-input').select2({
    placeholder: "Select..."
  });







// Just for the demo
$('#time-2').val ('');

})